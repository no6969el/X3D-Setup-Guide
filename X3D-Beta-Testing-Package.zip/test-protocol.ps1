# Simple test to demonstrate the X3D testing protocol implementation

# Import our test infrastructure
. .\temp\X3D-Test-Infrastructure.ps1

Write-Host "=== Testing X3D Protocol Implementation ===" -ForegroundColor Cyan

# Test the core functions
Write-Host "1. Testing topology resolution..." -ForegroundColor Yellow
try {
    $topology = Get-X3DTopology
    Write-Host "   Topology retrieved successfully" -ForegroundColor Green
    Write-Host "   CCD Count: $($topology.Ccds.Count)" -ForegroundColor Green
} catch {
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "2. Testing class resolution..." -ForegroundColor Yellow
try {
    $topology = Get-X3DTopology
    $class = Resolve-X3DClass -Topology $topology
    Write-Host "   Class resolved: $($class.Class)" -ForegroundColor Green
    Write-Host "   Confidence: $($class.Confidence)" -ForegroundColor Green
} catch {
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "3. Testing corpus test..." -ForegroundColor Yellow
try {
    $corpus = Test-X3DDetectionCorpus
    Write-Host "   Corpus test completed: $($corpus.Passed)/$($corpus.TotalTests) passed" -ForegroundColor Green
} catch {
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== X3D Protocol Implementation Test Complete ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Key features implemented:" -ForegroundColor Green
Write-Host "  ✓ Topology-based class detection" -ForegroundColor Green
Write-Host "  ✓ Per-CCD testing capability" -ForegroundColor Green
Write-Host "  ✓ Clock stretching detection" -ForegroundColor Green
Write-Host "  ✓ Environment fingerprinting" -ForegroundColor Green
Write-Host "  ✓ Stability testing framework" -ForegroundColor Green