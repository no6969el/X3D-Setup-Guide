# X3D Testing Protocol — Best Practices and Implementation Guide

**Companion to:** `X3D-Chip-Class-Reference.md`
**Covers:** Phase 1 — test-case design, automated validation, result documentation, backward compatibility
**Depth focus:** detection/topology, undervolt + stability, benchmarking + baselines

---

## 0. Five design axioms

Everything below follows from these. If a protocol decision conflicts with one of them, the protocol is wrong.

1. **Class is derived from topology, never from a model string.** Model strings are a *label* on a topology fact. The 9950X3D2 proved the catalogue goes stale within months; topology-derived classification degrades gracefully, string matching fails hard.

2. **"Didn't crash" is not "stable."** An over-aggressive negative Curve Optimizer offset frequently produces *clock stretching* rather than a crash — the core reports a frequency it isn't achieving. A protocol that only watches for crashes will certify configurations that are net performance losses. Effective-clock measurement is mandatory, not optional.

3. **Per-CCD is the minimum unit of state for Class B and C.** Any test that emits a single scalar per package cannot express a correct Class B result. Design the data model per-CCD from the start; collapsing to a scalar later is trivial, expanding later is a rewrite.

4. **A benchmark result without its variance is not a result.** Most X3D deltas of interest sit in the 0–6% band, which overlaps run-to-run noise on several common workloads. Report median and spread, and gate any claim below your measured noise floor.

5. **Every test run is invalid unless its environment is captured.** AGESA version, BIOS version, chipset driver version, MCR state, power plan, and Windows build all move X3D results materially. Capture them automatically; humans will forget.

---

## 1. Test matrix — what differs by class

The purpose of a class-aware protocol is that each class has a *different failure mode*. Testing all three the same way wastes time on A and misses bugs on B.

| Dimension | Class A | Class B | Class C |
|---|---|---|---|
| Distinct CCDs to sweep | 1 | **2, independently binned** | 2, similarly binned |
| Scheduling variable | none | **core parking — must be verified per run** | none |
| Dominant failure mode | voltage / clock stretching (Zen 3/4); thermal (Zen 5) | per-CCD divergence, parking not engaging | sustained thermal under 270 W class load |
| Benchmark selection | cache-sensitive gaming | gaming **with parking state logged** + mixed | gaming + large-working-set production |
| Minimum test duration | 8 h | 8 h **per CCD** | 8 h + sustained thermal soak |
| Detection edge cases | none significant | disabled-CCD enumerates as single-CCD | **two CCDs both report 96 MB** |
| Expected sweep time | ~1× | ~2.5× | ~2× |

### 1.1 Class-specific test cases to write first

**Class A**
- Baseline CO sweep, all-core then per-core refinement
- Zen 3/4: voltage-ceiling behaviour — confirm the part is voltage-limited, not power-limited, before interpreting results
- Zen 5: Curve Shaper surface (not just scalar CO), thermal-limited behaviour, positive-offset handling for a single weak core
- AM4 (5800X3D) path: DDR4, no MCR, locked multiplier — verify the tool doesn't offer DDR5/Zen 5 primitives

**Class B**
- Per-CCD independent sweep with **divergence assertion** — CCD0 and CCD1 optima should differ; if your tool reports them identical, that's a bug signal, not a lucky chip
- Core-parking verification harness (see §4.3)
- Disabled-CCD configuration: part enumerates as single-CCD but is *not* Class A
- Cross-CCD thread migration during a sweep (a migrating stability workload gives meaningless per-CCD results)

**Class C**
- Two-CCDs-both-96 MB topology resolution — the primary regression risk for logic written against Class B
- Sustained all-core thermal soak at ~270 W PPT
- Cross-CCD L3 latency characterisation (192 MB is two 96 MB pools, not one)
- Confirm no parking logic engages (Class B code paths must not fire)

---

## 2. Detection and topology validation

### 2.1 The 99.5% target is meaningless without corpus design

A 99.5% accuracy target against a corpus of common desktop SKUs will report ~100% and tell you nothing. Two consequences:

- **Sample-size floor.** To *demonstrate* ≥99.5% with any confidence you need on the order of 600+ independent classification trials with zero errors (rule of three: zero failures in *n* trials gives roughly 95% confidence that the true rate is below 3/*n*; 3/600 = 0.5%). You will not have 600 physical CPUs. This forces a **fixture-based** approach — serialise real topology dumps and synthesise the rest.
- **Corpus must be adversarial.** Weight it toward the cases that break things, not the cases that work.

### 2.2 Corpus composition

| Bucket | Target share | Contents |
|---|---|---|
| Real hardware dumps | as many as you can get | One per SKU you can physically access; the ground truth anchor |
| Synthetic per-SKU | ~40% | Every SKU in the reference doc, generated from the catalogue |
| Disabled-CCD variants | ~15% | Every Class B/C SKU with CCD1 disabled in BIOS |
| Unknown/future SKUs | ~15% | Plausible SKUs absent from the catalogue — tests graceful degradation |
| Malformed / edge | ~15% | Unit-mismatched L3 (MB vs KB vs bytes), missing fields, truncated masks, single-core VM |
| Non-X3D controls | ~15% | 9950X, 7700X, 5800X — must classify as "not X3D," not as a class |

**Grading is three-tier, not binary:**

| Outcome | Meaning | Counts as |
|---|---|---|
| Correct | Right class **and** right SKU | Pass |
| Degraded | Right class, SKU unknown, confidence flagged low | **Pass** (this is the desired unknown-SKU behaviour) |
| Wrong | Wrong class, or unknown SKU silently assigned a wrong class | Fail |
| Crash | Exception, hang | Fail (and severity-1) |

Silently guessing a wrong class on an unknown SKU is the worst outcome — worse than refusing to classify — because downstream tuning acts on it.

### 2.3 Classification rules to test explicitly

```
CCD count == 1                          -> Class A
CCD count == 2, exactly one CCD ~96 MB  -> Class B
CCD count == 2, both CCDs ~96 MB        -> Class C
CCD count == 2, neither CCD ~96 MB      -> not X3D
CCD count >= 3                          -> out of scope (Threadripper/EPYC) — refuse, don't guess
```

Normalise L3 before comparison. `96 MB`, `98304 KB`, and `100663296 B` are the same number and all three appear in the wild depending on enumeration path. Compare with a tolerance band rather than equality.

### 2.4 Scaffolding

**Fixture schema** (`fixtures/<sku>-<variant>.json`):

```json
{
  "fixtureId": "9950x3d2-stock",
  "source": "hardware|synthetic",
  "capturedOn": "2026-07-26",
  "environment": {
    "agesa": "1.2.7.1",
    "biosVersion": "F32e",
    "chipsetDriver": "7.01.14.132",
    "windowsBuild": "26100.4061"
  },
  "cpuid": { "vendor": "AuthenticAMD", "family": 26, "model": 68, "stepping": 0 },
  "brandString": "AMD Ryzen 9 9950X3D2 16-Core Processor",
  "topology": {
    "physicalCores": 16,
    "logicalCores": 32,
    "ccds": [
      { "index": 0, "cores": [0,1,2,3,4,5,6,7],    "l3Bytes": 100663296, "l2Bytes": 8388608 },
      { "index": 1, "cores": [8,9,10,11,12,13,14,15], "l3Bytes": 100663296, "l2Bytes": 8388608 }
    ]
  },
  "expected": {
    "class": "C",
    "sku": "9950X3D2",
    "vcachePerCcd": [true, true],
    "confidence": "high"
  }
}
```

**Detection functions:**

```powershell
function Get-X3DTopology {
<#
.SYNOPSIS
    Resolves physical CPU topology into a normalised, per-CCD structure.
.PARAMETER Fixture
    Optional path to a fixture JSON. When supplied, no hardware is queried —
    this is what makes detection testable at corpus scale.
.OUTPUTS
    [pscustomobject] with .Ccds (array), .PhysicalCores, .BrandString, .CpuId
.NOTES
    MUST NOT reference model names. Topology only.
#>
    [CmdletBinding()]
    param([string]$Fixture)

    if ($Fixture) { return ConvertFrom-X3DFixture -Path $Fixture }

    # Hardware path: enumerate cache relationships, group cores by shared L3 mask.
    # Each distinct L3 sharing group == one CCD.
    # Normalise all cache sizes to bytes here, once.
}

function Resolve-X3DClass {
<#
.SYNOPSIS
    Pure function: topology in, classification out. No I/O, no globals.
.OUTPUTS
    [pscustomobject] @{ Class; VCachePerCcd; Confidence; Reason }
.NOTES
    Confidence is 'high' when the SKU is also matched in the catalogue,
    'topology-only' when the class is derived but the SKU is unknown.
    NEVER returns a class it cannot justify from topology.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory)][psobject]$Topology)
}

function Test-X3DDetectionCorpus {
<#
.SYNOPSIS
    Runs every fixture through Resolve-X3DClass and grades Correct/Degraded/Wrong/Crash.
.PARAMETER FixturePath
    Directory of fixture JSON files.
.OUTPUTS
    Summary object plus a per-fixture result table for the validation report.
#>
    [CmdletBinding()]
    param([string]$FixturePath = "$PSScriptRoot/fixtures")

    $results = foreach ($f in Get-ChildItem $FixturePath -Filter *.json) {
        $fx = Get-Content $f -Raw | ConvertFrom-Json
        try {
            $actual = Resolve-X3DClass -Topology (Get-X3DTopology -Fixture $f.FullName)
            $grade =
                if ($actual.Class -eq $fx.expected.class -and $actual.Sku -eq $fx.expected.sku) { 'Correct' }
                elseif ($actual.Class -eq $fx.expected.class -and $actual.Confidence -ne 'high') { 'Degraded' }
                else { 'Wrong' }
        } catch { $grade = 'Crash' }
        [pscustomobject]@{ Fixture = $fx.fixtureId; Expected = $fx.expected.class
                           Actual = $actual.Class; Grade = $grade }
    }
    $results
}
```

**Golden-fixture discipline:** every time you fix a detection bug, add the fixture that caught it. The corpus becomes a permanent regression net, and this is the cheapest backward-compatibility guarantee available.

---

## 3. Undervolt and stability protocol

### 3.1 Search strategy

Do **not** linear-scan from 0 to −60. Use a bounded bisection with a safety ratchet:

1. **Establish the ceiling.** Sweep downward in coarse steps (−5) until first failure. This is the *failure boundary*, not the answer.
2. **Bisect** between last-pass and first-fail at step 1.
3. **Back off by a safety margin** — typically 3–5 counts from the bisected boundary. The boundary found in a 20-minute test is not the boundary that holds for 8 hours or across ambient temperature swings.
4. **Long-soak validate** the backed-off value at full duration.

Expected sweep cost: Class A ~1×, Class C ~2×, Class B ~2.5× (independent per-CCD sweeps, plus a combined confirmation pass).

### 3.2 Starting points by class

All values below are **starting hypotheses for search, not recommendations** — silicon lottery, board, and AGESA all move them.

| Target | Coarse start | Coarse step | Expected boundary band |
|---|---|---|---|
| 5800X3D (Zen 3, A) | −10 | −5 | −15 to −30 |
| 7800X3D (Zen 4, A) | −15 | −5 | −20 to −30 |
| 9800X3D / 9850X3D (Zen 5, A) | −20 | −5 | −25 to −45, board-dependent |
| 7900X3D / 7950X3D (Zen 4, B) | −15 **per CCD** | −5 | cache CCD typically shallower than frequency CCD |
| 9900X3D / 9950X3D (Zen 5, B) | −20 **per CCD** | −5 | wide divergence expected between CCDs |
| 9950X3D2 (Zen 5, C) | −20 per CCD | −5 | CCDs expected to land close; large divergence is a signal to investigate |

**Zen 5 requires a second dimension.** Curve Shaper is a frequency × temperature surface, not a scalar. Sweeping only the scalar CO on a Zen 5 part under-describes the tuning space. Practical approach: find the scalar CO boundary first, then use Curve Shaper to recover stability in the specific band where failures cluster (usually low-frequency/low-load), which then permits a deeper scalar offset.

**Board-reported vs applied offsets.** On Zen 5, boards have been observed accepting −50/−60 while monitoring tools report a different applied value. Always read back the applied offset from an independent source and assert it matches what you set. A sweep that silently isn't applying its offsets produces a beautiful, entirely fictional result.

### 3.3 Workload ladder — order matters

Undervolt failures do **not** appear first under maximum load. They appear at idle and light load, where voltage is lowest. A protocol that runs Prime95 first and calls it stable is inverted.

| Stage | Workload | Duration | Catches |
|---|---|---|---|
| 1 | Idle / desktop, aggressive C-states | 30 min | The most common undervolt failure — low-voltage idle instability |
| 2 | Single-thread boost (Cinebench 1T loop, y-cruncher 1T) | 30 min | Peak-boost voltage instability |
| 3 | Light mixed load (browser, background tasks) | 30 min | Transition/ramp instability |
| 4 | All-core sustained (y-cruncher, OCCT) | 2 h | Power/thermal limits, clock stretching |
| 5 | Load-transient cycling (alternating 1T ↔ all-core) | 1 h | LLC/droop instability — the hardest class to catch |
| 6 | Real workload (game loop, compile loop) | 4 h | Everything the synthetics miss |

Total ≥ 8 hours. For Class B, stages 1–5 run **per CCD** with affinity pinned; stage 6 runs unpinned with parking verified.

### 3.4 Failure taxonomy — classify, don't just count

| Signal | Classification | Action |
|---|---|---|
| Hard crash / reboot | Hard instability | Back off ≥5 counts |
| BSOD (WHEA_UNCORRECTABLE_ERROR) | Hard instability | Back off ≥5 counts |
| WHEA corrected-error counter increments | **Soft instability** — the most valuable early signal | Back off 3 counts; do not certify |
| Application crash, no OS event | Soft instability | Back off 3 counts |
| Effective clock < reported clock beyond tolerance | **Clock stretching** | Back off; this is a perf regression, not a stability pass |
| Benchmark score regresses vs baseline at deeper offset | Clock stretching (indirect) | Back off |
| Nothing, full duration | Pass | Certify at this offset |

**Clock-stretching detection is the piece most frameworks omit.** Implementation: sample reported clock and effective clock concurrently under a fixed all-core load. On a healthy configuration these track within a few percent. A widening gap as offsets deepen is the stretching signature. Set the tolerance empirically per-SKU from the stock baseline — don't hard-code a universal number.

### 3.5 Crash safety and resumability

A stability sweep will crash the machine by design. Build for it:

- **Persist state before every step**, not after. Write intended offset + step index to disk, then apply, then test. On boot, read the file: if a step was in-flight, that step failed.
- **Watchdog + auto-resume**: scheduled task on boot that reads the state file and continues the sweep.
- **Failure counter with a hard stop.** Three consecutive boot failures at a step → revert to last-known-good and halt. Do not loop.
- **BIOS-level escape hatch documented** for the operator: CMOS clear procedure, and where the last-known-good profile is stored.
- **Never leave the machine in an untested state at exit.** On abort, revert to stock, not to the last attempted value.

### 3.6 Scaffolding

```powershell
function Invoke-X3DUndervoltSweep {
<#
.SYNOPSIS
    Bounded bisection search for the deepest stable CO offset, per CCD.
.PARAMETER CcdIndex
    Which CCD to sweep. Class A callers pass 0. Class B/C callers loop.
.PARAMETER CoarseStart / CoarseStep / FloorOffset
    Search bounds. FloorOffset is a hard safety stop, never exceeded.
.PARAMETER SafetyMargin
    Counts to back off from the discovered boundary. Default 4.
.PARAMETER Resumable
    When set, writes/reads sweep state so a crash-reboot continues the sweep.
.OUTPUTS
    @{ CcdIndex; Boundary; Certified; FailureMode; Evidence }
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][int]$CcdIndex,
        [int]$CoarseStart   = -15,
        [int]$CoarseStep    = -5,
        [int]$FloorOffset   = -60,
        [int]$SafetyMargin  = 4,
        [switch]$Resumable
    )
    # 1. coarse descend until Test-X3DStability fails or FloorOffset reached
    # 2. bisect between lastPass and firstFail
    # 3. apply SafetyMargin
    # 4. Assert-X3DOffsetApplied  <-- verify the board actually took it
    # 5. long-soak at the final value
}

function Test-X3DStability {
<#
.SYNOPSIS
    Runs the staged workload ladder and returns a classified result.
.PARAMETER Stages
    Which ladder stages to run. Coarse search uses 1..3 (fast);
    certification runs 1..6 (full ~8h).
.PARAMETER CcdAffinity
    Pin the workload to one CCD's cores. Required for Class B per-CCD sweeps —
    an unpinned workload migrating across CCDs makes per-CCD results meaningless.
.OUTPUTS
    @{ Passed; FailureMode; WheaDelta; ClockStretchRatio; StageFailed }
#>
    [CmdletBinding()]
    param(
        [int[]]$Stages = @(1,2,3,4,5,6),
        [int[]]$CcdAffinity,
        [timespan]$MaxDuration
    )
}

function Measure-X3DClockStretch {
<#
.SYNOPSIS
    Concurrent reported-vs-effective clock sampling under fixed load.
.OUTPUTS
    @{ ReportedMHz; EffectiveMHz; Ratio; ExceedsTolerance }
.NOTES
    Tolerance is derived from this SKU's stock baseline, captured by
    New-X3DBaseline. Do not hard-code a universal threshold.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory)][int]$DurationSeconds, [int[]]$CcdAffinity)
}

function Assert-X3DOffsetApplied {
<#
.SYNOPSIS
    Reads back the applied CO offset from an independent source and compares
    to the intended value. Throws on mismatch.
.NOTES
    Guards against the Zen 5 case where the board accepts an offset it does
    not apply, producing a fictitious sweep result.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory)][int]$CcdIndex, [Parameter(Mandatory)][int]$Expected)
}
```

---

## 4. Benchmarking and baselines

### 4.1 Establish the noise floor before measuring anything

The single most important benchmarking step, and the one most often skipped: **run your benchmark suite N times at stock, changing nothing, and measure the spread.** That spread is your noise floor. Any delta smaller than it is not a result.

This matters acutely for X3D work because the interesting deltas are small. The 9950X3D2 vs 9950X3D gap is 0–6% in gaming — much of which independent testing found to be within run-to-run variance. 7-Zip decompression in particular showed elevated variance on both 9950X3D and 9950X3D2, enough that the ranking between parts changed between data sets. If your framework reports "9950X3D2 is 2% faster" without a variance figure, it is reporting noise with a decimal point.

### 4.2 Run-count and statistics

| Rule | Value |
|---|---|
| Minimum runs per configuration | 5 |
| Runs when measured spread > 3% | 7–9 |
| Discard | First run (warm-up/shader-cache), always |
| Central tendency | **Median**, not mean — resistant to the single outlier run |
| Spread | Median absolute deviation, or min/max range |
| Reporting threshold | Flag any delta < measured noise floor as "within variance" |
| Minimum detectable effect | State it explicitly in every report |

Report frame-time lows (1% and 0.1%) alongside averages for gaming workloads — cache effects show up disproportionately in lows, and an average-only report will understate X3D's actual character.

### 4.3 Class B: verify core parking or discard the run

This is non-negotiable and is the leading cause of irreproducible Class B results. A Class B gaming benchmark where parking did not engage is not a slow result — it is an **invalid** result and must be discarded, not averaged in.

Verification method: sample per-core utilisation throughout the run and assert that the non-cache CCD's cores stayed parked for ≥95% of the run window.

Known failure causes to check and log:
- Xbox Game Bar not detecting the title (launcher/wrapper defeats detection)
- 3D V-Cache Performance Optimizer driver missing or stale
- AMD chipset driver version mismatch
- Power plan overriding CPPC preferred-core ordering
- CPPC disabled in BIOS

```powershell
function Test-X3DCoreParking {
<#
.SYNOPSIS
    Samples per-CCD utilisation during a benchmark run and asserts the
    expected parking state for the detected class.
.PARAMETER ExpectedState
    'GameParked'  - non-cache CCD parked (Class B, gaming)
    'AllActive'   - both CCDs active (Class B productivity; Class C always)
.OUTPUTS
    @{ Valid; ParkedFraction; ExpectedState; ObservedState; DiscardRun }
.NOTES
    Class C must return AllActive. If Class B parking logic fires on a
    Class C part, that is a classification bug — fail loudly.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('GameParked','AllActive')][string]$ExpectedState,
        [double]$MinParkedFraction = 0.95
    )
}
```

### 4.4 Environment control

Capture automatically with every run; treat any change as invalidating the baseline:

AGESA version · BIOS version · chipset driver version · GPU driver version · Windows build · power plan · MCR state · EXPO/memory profile · FCLK/UCLK/MCLK · resolved CO offsets per CCD · ambient temperature · cooler model and fan curve.

Additionally: fix the GPU (a GPU-bound test measures nothing about the CPU), disable background updates and telemetry during runs, pin the resolution/settings preset, and never compare across a Windows feature update.

### 4.5 Per-class benchmark selection

| Class | Core suite | Why |
|---|---|---|
| A | Cache-sensitive titles (Baldur's Gate 3, Cyberpunk, Stellaris sim-time, F1) + Cinebench 1T | Pure gaming part; sim-time metrics beat FPS where available |
| B | Same gaming suite **with parking verified**, plus mixed productivity | Must measure both scheduling states |
| C | Gaming suite + large-working-set production: code compile, 7-Zip compression, CFD/scientific | The only workloads where dual-cache showed real movement; compile and 7-Zip compression were the standouts, decompression showed nothing |

For Class C specifically, include at least one workload with a working set exceeding 96 MB. Below that threshold you are measuring clocks, not cache, and will conclude the extra cache does nothing — which is true for most workloads but not the point of the test.

### 4.6 Baseline capture and regression gates

```powershell
function New-X3DBaseline {
<#
.SYNOPSIS
    Captures a stock-settings baseline: performance, clock behaviour,
    thermals, power, and the environment fingerprint.
.NOTES
    Run BEFORE any tuning. This is the reference for both regression
    detection and the per-SKU clock-stretch tolerance.
#>
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$OutputPath, [int]$Runs = 7)
}

function Compare-X3DResult {
<#
.SYNOPSIS
    Compares a tuned result against a baseline with variance awareness.
.OUTPUTS
    @{ DeltaPercent; NoiseFloor; Significant; Verdict }
    Verdict is 'improved' | 'regressed' | 'within-variance'.
.NOTES
    Refuses to compare across differing environment fingerprints —
    returns 'incomparable' rather than a misleading number.
#>
    [CmdletBinding()]
    param([psobject]$Baseline, [psobject]$Candidate)
}
```

**Regression gates for CI:** any tuned configuration that regresses a benchmark beyond the noise floor fails, even if it passed stability. Stability and performance are separate gates and a configuration must pass both — this is precisely the case that catches clock stretching.

---

## 5. Backward compatibility

| Practice | Detail |
|---|---|
| **Version the result schema** | Add a `schemaVersion` field now. Write a reader that upgrades old records rather than rejecting them. |
| **Golden-output tests** | Freeze the current output for a set of known inputs. Any diff must be deliberate and reviewed. This is how you refactor topology resolution for Class C without silently breaking Class A. |
| **Additive-only for one cycle** | New fields default to a value that reproduces old behaviour. Remove old fields a release later, not the same release. |
| **Deprecation shims** | Keep the old scalar-offset accessor, implemented as "CCD 0's offset," with a warning. Remove after consumers migrate. |
| **Test the old path explicitly** | A test that only runs the new per-CCD path doesn't prove the compatibility shim works. |
| **Catalogue is data, not code** | Adding a SKU should be a data-file edit with no logic change. If a new SKU requires a code change, the classifier is doing string matching somewhere. |

---

## 6. Result schema

One record per test run. Denormalised on purpose — a result you can't interpret in isolation two months later is worthless.

```json
{
  "schemaVersion": 2,
  "runId": "2026-07-26T14:22:10Z-9950x3d2-uv-ccd0",
  "chip": {
    "sku": "9950X3D2", "class": "C", "architecture": "Zen 5",
    "detectionConfidence": "high", "ccdCount": 2,
    "l3PerCcdBytes": [100663296, 100663296], "vcachePerCcd": [true, true]
  },
  "environment": {
    "agesa": "1.2.7.1", "bios": "F32e", "chipsetDriver": "7.01.14.132",
    "gpuDriver": "591.86", "windowsBuild": "26100.4061",
    "powerPlan": "Balanced", "memoryContextRestore": false,
    "memoryProfile": "EXPO DDR5-6000 CL30", "fclkMHz": 2000, "uclkRatio": "1:1",
    "cooler": "360mm AIO", "ambientC": 22.5
  },
  "configuration": {
    "coOffsetPerCcd": [-24, -22],
    "curveShaper": { "applied": true, "points": [] },
    "pptW": 270, "tdcA": 180, "edcA": 240
  },
  "stability": {
    "stagesRun": [1,2,3,4,5,6], "durationHours": 8.2, "passed": true,
    "failureMode": null, "wheaDelta": 0,
    "clockStretchRatio": 0.991, "stretchTolerance": 0.97
  },
  "performance": {
    "runs": 7, "discardedFirstRun": true,
    "metrics": [
      { "name": "Cyberpunk2077-1080p-High", "median": 231.4, "mad": 2.1,
        "unit": "fps", "low1pct": 178.2, "low01pct": 151.0,
        "parkingVerified": null }
    ],
    "noiseFloorPercent": 1.8, "minimumDetectableEffectPercent": 2.5
  },
  "verdict": { "certified": true, "vsBaseline": "+3.1%", "significant": true }
}
```

Note `parkingVerified: null` for Class C — the field exists for schema stability but is not applicable. For Class B it must be `true` or the run is discarded.

---

## 7. Automation and CI

**What can run unattended:** detection corpus (pure functions, no hardware — run on every commit), schema validation, golden-output diffs, report generation, statistical analysis.

**What cannot:** anything that applies voltage. Stability sweeps crash machines and need a physical or IPMI-recoverable host, a watchdog, and a documented CMOS-clear escape.

Suggested split:

| Tier | Trigger | Contents | Duration |
|---|---|---|---|
| Unit | Every commit | Detection corpus, classification rules, schema, golden outputs | < 2 min |
| Integration | Every PR | Full corpus incl. adversarial fixtures, backward-compat shims | < 15 min |
| Hardware smoke | Nightly, per bench | Detect → baseline → short stability (stages 1–3) | ~2 h |
| Hardware full | Weekly / pre-release | Full per-class sweep + certification | 8–24 h per chip |

---

## 8. Documenting validation results

Per chip family, produce a report containing:

1. **Chip identity + detection confidence** — including whether it was catalogue-matched or topology-derived
2. **Environment fingerprint** — verbatim, not summarised
3. **Baseline** — stock performance, clocks, thermals, power, with variance
4. **Sweep trace** — every offset attempted, its outcome, and its failure classification. The failures are more informative than the final value.
5. **Certified configuration** — per-CCD, with the safety margin applied and stated
6. **Performance delta vs baseline** — with noise floor and significance verdict
7. **Class-specific evidence** — parking verification (B), per-CCD divergence (B/C), thermal soak (C)
8. **Anomalies and open questions**

Reports should be diffable. Same section order, same field names, machine-readable data alongside prose — so that "what changed between AGESA 1.2.7.0 and 1.2.7.1 on this chip" is a diff, not an archaeology project.

---

## 9. Common pitfalls

| Pitfall | Consequence | Guard |
|---|---|---|
| Certifying on "no crash" alone | Ships a slower configuration | Effective-clock measurement in every stability pass |
| Running Prime95 first | Misses idle-voltage failures entirely | Ladder starts at idle, stage 1 |
| All-core CO on Class B | Wrong on one CCD by construction | Per-CCD sweep with divergence assertion |
| Unpinned workload during per-CCD sweep | Results attributed to the wrong CCD | Mandatory `CcdAffinity` parameter |
| Class B benchmark without parking check | Irreproducible, unexplainable numbers | Discard runs failing `Test-X3DCoreParking` |
| MCR left enabled during training validation | Measuring a restored context, not a training result | Assert MCR disabled; record state in every fingerprint |
| Comparing across AGESA versions | Silent invalidation | Environment fingerprint gate in `Compare-X3DResult` |
| Trusting software power readings | Understates real draw substantially — measured EPS12V draw ran ~285 W where software reported ~250 W on the 9950X3D2 | Hardware interposer for any absolute power claim; software readings are relative-only |
| Model-string classification | Breaks on every new SKU | Topology-derived class, catalogue only for SKU naming |
| Assuming the board applied your offset | Fictitious sweep results on Zen 5 | `Assert-X3DOffsetApplied` after every write |
| Reporting a 2% delta as a win | Noise presented as signal | Noise floor computed and published with every comparison |

---

## 10. Phase 1 execution checklist

**Test cases per class**
- [ ] Class A: Zen 3 (AM4/DDR4), Zen 4, Zen 5 (Curve Shaper, positive offsets, unlocked multiplier) paths distinguished
- [ ] Class B: per-CCD sweep, divergence assertion, parking verification, disabled-CCD case
- [ ] Class C: both-CCDs-96 MB resolution, no-parking assertion, thermal soak, >96 MB working-set workload
- [ ] Non-X3D and out-of-scope (≥3 CCD) parts refused, not misclassified

**Automated validation**
- [ ] Fixture schema frozen and versioned
- [ ] Corpus built to the §2.2 composition, adversarial buckets included
- [ ] Four-tier grading (Correct/Degraded/Wrong/Crash) implemented; Degraded counts as pass
- [ ] Detection corpus runs in CI on every commit
- [ ] Sweep is crash-resumable with a hard failure stop and stock-revert on abort
- [ ] `Assert-X3DOffsetApplied` wired into every offset write

**Documentation**
- [ ] Report template with the §8 sections
- [ ] Result schema v2 with `schemaVersion` present
- [ ] Reports diffable across AGESA/BIOS revisions

**Backward compatibility**
- [ ] Golden-output tests captured from current behaviour before refactoring
- [ ] Scalar-offset accessor retained as a deprecation shim with warning
- [ ] Old-path tests run explicitly, not just the new per-CCD path
- [ ] Catalogue is data-only; adding a SKU requires no code change

---

## Appendix — Quick reference: what each class needs that the others don't

**Class A only:** AM4/DDR4 code path (5800X3D), locked-multiplier handling, Zen 3/4 voltage-ceiling interpretation.

**Class B only:** per-CCD divergence assertion, core-parking verification, Game Bar / optimizer-driver dependency checks, disabled-CCD detection, CPPC preferred-core validation.

**Class C only:** dual-96 MB topology resolution, negative assertion that Class B parking logic does not fire, sustained ~270 W thermal soak, cross-CCD L3 latency characterisation, >96 MB working-set benchmark.

**All classes:** effective-clock/stretching detection, environment fingerprinting, noise-floor computation, crash-resumable sweeps, revert-to-stock on abort.
