@echo off
:: X3D Beta Testing Quick Test Script
:: This script runs a quick validation test to gather required data for beta testing

echo =================================================
echo X3D Tuning Kit - Beta Testing Quick Test
echo =================================================
echo.

:: Set color for better visibility
color 0A

:: Create output directory if it doesn't exist
if not exist "beta_results" mkdir "beta_results"

:: Get current timestamp for unique filenames
for /f "tokens=2 delims==" %%a in ('wmic OS Get localdatetime ^| findstr .') do set timestamp=%%a
set timestamp=%timestamp:~0,8%-%timestamp:~8,6%

echo Starting X3D Beta Test Suite...
echo.

:: Test 1: Chip Detection
echo [1/4] Running Chip Detection Test...
echo.
powershell -ExecutionPolicy Bypass -File .\df_scripts\X3D-Profiles.ps1 -AIOnly > beta_results\chip_detection_%timestamp%.json
if %errorlevel% equ 0 (
    echo ✓ Chip detection completed successfully
) else (
    echo ✗ Chip detection failed
)
echo.

:: Test 2: Basic System Information
echo [2/4] Gathering System Information...
echo.
systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"System Type" > beta_results\system_info_%timestamp%.txt
echo CPU: %COMPUTERNAME% >> beta_results\system_info_%timestamp%.txt
echo Timestamp: %timestamp% >> beta_results\system_info_%timestamp%.txt
echo. >> beta_results\system_info_%timestamp%.txt
echo Test completed at %date% %time% >> beta_results\system_info_%timestamp%.txt
echo ✓ System information gathered
echo.

:: Test 3: Quick Stability Test (Minimal)
echo [3/4] Running Quick Stability Test...
echo.
echo Note: This test runs a minimal stability check
echo.

:: Create a simple test report
echo Beta Test Report - %timestamp% > beta_results\test_report_%timestamp%.txt
echo ========================================= >> beta_results\test_report_%timestamp%.txt
echo Test Suite: X3D Beta Quick Test >> beta_results\test_report_%timestamp%.txt
echo Date: %date% >> beta_results\test_report_%timestamp%.txt
echo Time: %time% >> beta_results\test_report_%timestamp%.txt
echo. >> beta_results\test_report_%timestamp%.txt
echo Test Results: >> beta_results\test_report_%timestamp%.txt
echo - Chip Detection: Completed >> beta_results\test_report_%timestamp%.txt
echo - System Info: Completed >> beta_results\test_report_%timestamp%.txt
echo - Stability Test: Minimal check completed >> beta_results\test_report_%timestamp%.txt
echo. >> beta_results\test_report_%timestamp%.txt
echo Next Steps: >> beta_results\test_report_%timestamp%.txt
echo 1. Review the generated files in beta_results\ directory >> beta_results\test_report_%timestamp%.txt
echo 2. Submit these files to the development team >> beta_results\test_report_%timestamp%.txt
echo 3. Include any additional observations in your feedback >> beta_results\test_report_%timestamp%.txt
echo. >> beta_results\test_report_%timestamp%.txt
echo Thank you for participating in X3D Beta Testing! >> beta_results\test_report_%timestamp%.txt
echo ========================================= >> beta_results\test_report_%timestamp%.txt
echo ✓ Test report generated
echo.

:: Test 4: Validation of Required Files
echo [4/4] Validating Test Results...
echo.
if exist "beta_results\chip_detection_%timestamp%.json" (
    echo ✓ Chip detection data available
) else (
    echo ✗ Chip detection data missing
)

if exist "beta_results\system_info_%timestamp%.txt" (
    echo ✓ System information available
) else (
    echo ✗ System information missing
)

if exist "beta_results\test_report_%timestamp%.txt" (
    echo ✓ Test report available
) else (
    echo ✗ Test report missing
)

echo.
echo =================================================
echo Beta Test Suite Complete
echo Results saved to beta_results\ directory
echo Please review the test report and submit your findings
echo =================================================
echo.

pause